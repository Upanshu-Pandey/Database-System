drop table customer cascade constraints;
drop table Vehicle cascade constraints;
drop table Checkin cascade constraints;
drop table contract cascade constraints;

DROP SEQUENCE customer_Seq;
DROP SEQUENCE vehicle_Seq;
DROP SEQUENCE checkin_Seq;
DROP SEQUENCE contract_Seq;

CREATE TABLE Customer(
	Customer_ID	INTEGER NOT NULL,
	Customer_Name	VARCHAR(20),
	Customer_Location	VARCHAR(20) NOT NULL,
	CONSTRAINT	pk_Customer PRIMARY KEY (Customer_ID)
);


CREATE TABLE Vehicle(
	Vehicle_ID	INTEGER NOT NULL,
	Refill_Cost	INTEGER NOT NULL,
	Fuel_Amount_Percentage	INTEGER NOT NULL,
	Checkin_Date	DATE NOT NULL,
	Car_State	VARCHAR(20) NOT NULL,
	CONSTRAINT	pk_Vehicle PRIMARY KEY (Vehicle_ID)
);

CREATE TABLE Checkin(
	Checkin_ID	INTEGER NOT NULL,
    Checkin_Charge	INTEGER NOT NULL,
	fk1_Vehicle_ID	INTEGER NOT NULL,
    FOREIGN KEY (fk1_Vehicle_ID ) REFERENCES Vehicle(Vehicle_ID),
	CONSTRAINT	pk_Checkin PRIMARY KEY (Checkin_ID)
);

CREATE TABLE Contract(
	Contract_ID	INTEGER NOT NULL,
	Return_Deadline	DATE NOT NULL,
	Date_Returned	DATE NOT NULL,
	Hire_Charge	INTEGER NOT NULL,
	Supercharge	INTEGER NOT NULL,
	Total_Charge	INTEGER NOT NULL,
	fk1_Customer_ID	INTEGER NOT NULL,
	fk2_Vehicle_ID	INTEGER NOT NULL,
    FOREIGN KEY (fk1_Customer_ID) REFERENCES Customer(Customer_ID),
    FOREIGN KEY (fk2_Vehicle_ID ) REFERENCES Vehicle(Vehicle_ID),
	CONSTRAINT	pk_Contract PRIMARY KEY (Contract_ID)
);


--ALTER TABLE Contract ADD CONSTRAINT fk1_Contract_to_Customer FOREIGN KEY(fk1_Customer_ID) REFERENCES Customer(Customer_ID);

--ALTER TABLE Contract ADD CONSTRAINT fk2_Contract_to_Vehicle FOREIGN KEY(fk2_Vehicle_ID) REFERENCES Vehicle(Vehicle_ID);

--ALTER TABLE Checkin ADD CONSTRAINT fk1_Checkin_to_Vehicle FOREIGN KEY(fk1_Vehicle_ID) REFERENCES Vehicle(Vehicle_ID);

insert into customer values(1, 'Sajid Miya', 'Ratnapark');
insert into customer values(2, 'Swikrit Thapa',	'Thamel');
insert into customer values(3, 'Upanshu Pandey',	'Lazimpat');
insert into customer values(4,'Sakchyam Nakarmi',	'New Road');
insert into customer values(5, 'Samrat Karki',	'Uzbekistan');

insert into vehicle values(101,0,   100,	'05/03/2021',	'Good');
insert into vehicle values(102,600,	60,	'01/03/2020',	'Good');
insert into vehicle values(103,750,	75,	'06/04/2020',	'Bad');
insert into vehicle values(104,340,	34,	'07/02/2021',	'Bad');
insert into vehicle values(105,850,	85,	'03/04/2022',	'Good');

insert into checkin values(1,5000,102);
insert into checkin values(2,4500,101);
insert into checkin values(3,7800,104);
insert into checkin values(4,4540,103);
insert into checkin values(5,6800,105);

insert into contract values(1,'01/05/2001',	'03/05/2001',	1000,	3000,	4000,2,102);
insert into contract values(2,'03/05/2015',	'03/05/2015',	2000,	0,	2000,1,103);
insert into contract values(3,'04/03/2010',	'04/03/2010',	1500,	0,	1500,3,101);
insert into contract values(4,'06/09/2008',	'06/09/2008',	900,	0,	900,4,104);
insert into contract values(5,'04/20/2013',	'04/20/2013',	1520,	0,	1520,5,105);

select v.Vehicle_id
from vehicle v, checkin c
where v.vehicle_id=c.fk1_Vehicle_ID;

select Vehicle_id, refill_cost, Car_State
from vehicle
where Car_State='Bad' and refill_cost<600;

select v.vehicle_id
from vehicle v, contract c
where c.total_charge<2000 and v.vehicle_id=c.fk2_Vehicle_ID;

select customer_id, v.vehicle_id
from customer c, vehicle v, contract con
where c.customer_id=con.fk1_Customer_ID and con.fk2_Vehicle_ID=v.vehicle_id;

select v.vehicle_id,c.date_returned, c.supercharge
from vehicle v, contract c
where v.vehicle_id=c.fk2_Vehicle_ID and c.date_returned>c.return_deadline;

CREATE SEQUENCE customer_Seq
start with 6
increment by 1;

CREATE SEQUENCE vehicle_Seq
start with 106
increment by 1;

CREATE SEQUENCE checkin_Seq
start with 6
increment by 1;

CREATE SEQUENCE contract_Seq
start with 6
increment by 1;

CREATE OR REPLACE TRIGGER Customer_ID_Create
BEFORE INSERT ON CUSTOMER
FOR EACH ROW
WHEN (NEW.CUSTOMER_ID IS NULL)
BEGIN
:NEW.CUSTOMER_ID :=customer_seq.nextval;
END Customer_ID_Create;
/

CREATE OR REPLACE TRIGGER Vehicle_ID_Create
BEFORE INSERT ON Vehicle
FOR EACH ROW
WHEN (NEW.Vehicle_ID IS NULL)
BEGIN
:NEW.Vehicle_ID :=vehicle_Seq.nextval;
END Vehicle_ID_Create;
/

CREATE OR REPLACE TRIGGER Checkin_ID_Create
BEFORE INSERT ON Checkin
FOR EACH ROW
WHEN (NEW.Checkin_ID IS NULL)
BEGIN
:NEW.Checkin_ID :=checkin_Seq.nextval;
END Checkin_ID_Create;
/

CREATE OR REPLACE TRIGGER Contract_ID_Create
BEFORE INSERT ON Contract
FOR EACH ROW
WHEN (NEW.Contract_ID IS NULL)
BEGIN
:NEW.Contract_ID :=Contract_Seq.nextval;
END Contract_ID_Create;
/

Create or replace trigger trig_Deadline_Check
after insert or update
on contract
for each row
begin
    if :new.Return_Deadline>:new.Date_Returned
    then
    dbms_output.put_line('Late return of vehicle');
    end if;
end trig_Deadline_Check;
/

Create or Replace trigger trig_Total_Check
after insert or update
on CONTRACT
for each row
begin
    if :new.total_charge!=:new.Hire_Charge+:new.Supercharge
    then 
    raise_application_error(-20001,'incorrect total fee');
    end if;
end trig_Total_Check;
/

Create or replace trigger trig_Fuel_Check
After insert or update
on vehicle
for each row
begin
    if :new.Fuel_Amount_Percentage>100
    then 
    raise_application_error(-20002,'Fuel Capacity cannot be more than 100');
    end if;
end trig_Fuel_Check;
/

Create or replace trigger trig_Checkin_Reminder
After insert or update
on vehicle
for each row
begin
    if :new.Car_State='Bad' or :new.Car_State='bad'
    then dbms_output.put_line('Checkin Required');
    elsif :new.Car_State='Good' or :new.Car_State='good'
    then dbms_output.put_line('Checkin not Required');
    else
    raise_application_error(-20003,'Please input valid vehicle state.');
    end if;
end trig_Checkin_Reminder;
/

Create or replace trigger trig_Customer_ID_Check
after insert
on Customer
for each row
begin
    if :new.Customer_ID<>null
    then
    raise_application_error(-20004,'Do not manually insert primary key.');
    end if;
end trig_Customer_ID_Check;
/

Create or replace trigger trig_Vehicle_ID_Check
after insert
on vehicle
for each row
begin
    if :new.Vehicle_ID<>null
    then
    raise_application_error(-20004,'Do not manually insert primary key.');
    end if;
end trig_Vehicle_ID_Check;
/

Create or replace trigger trig_Checkin_ID_Check
after insert
on checkin
for each row
begin
    if :new.Checkin_ID<>null
    then
    raise_application_error(-20004,'Do not manually insert primary key.');
    end if;
end trig_Checkin_ID_Check;
/

Create or replace trigger trig_Contract_ID_Check
after insert
on contract
for each row
begin
    if :new.Contract_ID<>null
    then
    raise_application_error(-20004,'Do not manually insert primary key.');
    end if;
end trig_Contract_ID_Check;
/